package com.example.SMS.liveChat.user;

public enum Status {
    ONLINE, OFFLINE
}
