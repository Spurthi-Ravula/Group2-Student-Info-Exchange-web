package com.example.SMS.liveChat.user;

public class AddUser {
    String email;
    Status status;
}
