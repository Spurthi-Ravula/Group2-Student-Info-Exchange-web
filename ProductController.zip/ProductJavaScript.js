document.getElementById("product-form").addEventListener("submit", function(event) {
    event.preventDefault();
    const name = document.getElementById("name").value;
    const price = document.getElementById("price").value;

    const data = {
        name: name,
        price: price
    };

    fetch("/products", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        }
        throw new Error("Error adding product");
    })
    .then(data => {
        document.getElementById("product-list").innerHTML += `<div>${data.name} - $${data.price}</div>`;
    })
    .catch(error => {
        console.error(error);
    });
});
