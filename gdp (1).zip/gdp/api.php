<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    // Handle user registration
    $data = json_decode(file_get_contents("php://input"));

    $firstName = $data->firstName;
    $lastName = $data->lastName;
    $username = $data->username;
    $password = $data->password;

    // Perform database insertion (replace with your actual database connection logic)
    $conn = new mysqli("localhost", "gdp", "Satya@9053", "sys");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (firstName, lastName, username, password) VALUES ('$firstName', '$lastName', '$username', '$hashedPassword')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['message' => 'User registered successfully']);
    } else {
        echo json_encode(['error' => 'Error: ' . $sql . '<br>' . $conn->error]);
    }

    $conn->close();
} else {
    // Handle other HTTP methods if necessary
    echo json_encode(['error' => 'Invalid request method']);
}
?>
