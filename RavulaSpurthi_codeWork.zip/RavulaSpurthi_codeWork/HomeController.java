package com.gdpdemo.GDPSprint1Project;

import java.util.Random;


import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.CurrentSecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


import com.gdpdemo.GDPSprint1Project.Repository.HomeRepository;
import com.gdpdemo.GDPSprint1Project.service.EmailService;


@Controller
public class HomeController {

	@Autowired
	private HomeRepository homeRepository;
	
	@Autowired
	private EmailService emailservice;
	

	ModelAndView mv = new ModelAndView();

	@RequestMapping("/")
	public String home() {
		return "Home";
	}
	
	@RequestMapping("/createpost")
	public String createPost() {
		return "createpost";
	}

	@RequestMapping("/Demo")
	public String Demo(Model model) {
		model.addAttribute("user", new Home());
		return "Demo";
	}

	@RequestMapping("/category")
	public String category() {
		return "category";
	}
	@RequestMapping("/dummy")
	public String dummy() {
		return "dummy";
	}

	


	@RequestMapping(value = "/ForgotPassword", method = RequestMethod.POST)
	public String registeredUser(@Validated @ModelAttribute("user") Home user, BindingResult result, Model model,
			HttpSession session) {
		try {
			if (!user.getPassword().contains(user.getRePassword())) {
				session.setAttribute("message", "Re-type your password correctly!!");
				throw new Exception("Re-type your password correctly!!");
			}

			if (result.hasErrors()) {
				System.out.println("Error" + result.toString());
				model.addAttribute("user", user);
				return "Demo";
			}
			
			Home home = this.homeRepository.getUserByUserName(user.getEmail());
			if(home==null) {
				System.out.println("USER" + user);
				/* Home save = homeRepository.save(user) */;
				Home save = homeRepository.save(user);
				model.addAttribute("user", new Home());
			session.setAttribute("email", user.getEmail());
			return "ForgotPassword";
			}
			if (user.getEmail().contains(home.getEmail())) {
				session.setAttribute("message", "User with this email already exists");
				return "Demo";
			}
			// session.setAttribute("message", new Message("Successfully Registered!!!",
			// "alert-success"));
			
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("user", user);
			session.setAttribute("message", e.getMessage());
			return "Demo";
		}
		return "Demo";
	}

	
	@RequestMapping("/ForgotPassword")
	public String ForgotPassword() {
		return "ForgotPassword";
	}

	@RequestMapping("/ResetPassword")
	public String ResetPassword() {
		return "ResetPassword";
	}

	@RequestMapping("/ChangePassword")
	public String ChangePassword() {
		return "ChangePassword";
	}

	

	


	@RequestMapping(value = "/change-password", method = RequestMethod.POST)
	public String changePassword(@RequestParam("newpassword") String newpassword, HttpSession session) {
		String email = (String) session.getAttribute("email");
		Home home = this.homeRepository.getUserByUserName(email);
		home.setPassword(newpassword);
		home.setRePassword(newpassword);
		this.homeRepository.save(home);
		session.setAttribute("message", new Message("Password Successfully Changed", "alert-success"));
		return "ResetSuccess";

	}
	


	
}
