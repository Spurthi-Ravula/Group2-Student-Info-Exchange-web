package com.gdpdemo.GDPSprint1Project;

import java.util.Random;


import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.CurrentSecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


import com.gdpdemo.GDPSprint1Project.Repository.HomeRepository;
import com.gdpdemo.GDPSprint1Project.service.EmailService;


@Controller
public class HomeController {

	@Autowired
	private HomeRepository homeRepository;
	
	@Autowired
	private EmailService emailservice;
	

	ModelAndView mv = new ModelAndView();

	@RequestMapping("/")
	public String home() {
		return "Home";
	}
	
	@RequestMapping("/createpost")
	public String createPost() {
		return "createpost";
	}

	@RequestMapping("/Demo")
	public String Demo(Model model) {
		model.addAttribute("user", new Home());
		return "Demo";
	}

	@RequestMapping("/category")
	public String category() {
		return "category";
	}
	@RequestMapping("/dummy")
	public String dummy() {
		return "dummy";
	}






	@RequestMapping("/Login")
	public String Login(Model model) {
		model.addAttribute("title", "Login Page");
		return "Login";
	}